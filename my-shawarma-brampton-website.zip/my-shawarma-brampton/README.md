# My Shawarma - Brampton Website

A responsive static website concept for My Shawarma, Gore & Ebenezer Rd, Brampton. Built with plain HTML, CSS, and JavaScript, so it can be deployed directly to Vercel without a build step.

## Preview locally
Open `index.html` in a browser, or run a local static server:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

## Deploy to Vercel
1. Create a new GitHub repository named `my-shawarma-brampton`.
2. Upload/push all files in this folder to the repository root.
3. In Vercel, choose **Add New → Project**, import the repository, and deploy.
4. Framework preset: **Other**. Build command: leave empty. Output directory: `.`

## Customize before launch
- Ordering buttons currently link to the restaurant's SkipTheDishes listing. Uber Eats is linked in the story section.
- Phone/address and Google Maps directions are set from the details supplied by the requester.
- Menu prices are intentionally not hard-coded, since delivery-platform prices and promotions can change.
- Food images are embedded from Unsplash as visual placeholders. Replace them with photos the restaurant owns or has permission to use before treating this as an official business website.
- Opening hours and ratings are not advertised as fixed facts because listings may vary.

## Files
- `index.html`: page content and links
- `styles.css`: responsive layout and styling
- `script.js`: mobile navigation and current year
